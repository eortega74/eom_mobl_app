# Duende + Skoruba + Java OIDC - Verificado

Todo probado y funcional.