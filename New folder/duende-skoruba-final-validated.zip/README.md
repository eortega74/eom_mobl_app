# Proyecto verificado: Duende + Skoruba + Java OIDC

Levanta con Docker Compose. Login y flujo funcional.