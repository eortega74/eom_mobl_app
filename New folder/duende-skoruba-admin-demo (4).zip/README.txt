Duende IdentityServer + Skoruba Admin UI + Spring Boot Java OIDC client.
Run `docker-compose up --build` after compiling the Java app.