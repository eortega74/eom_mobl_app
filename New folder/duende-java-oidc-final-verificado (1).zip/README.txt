1. Ejecuta: docker-compose build
2. Luego: docker-compose up
3. Accede a http://localhost:8080/login
