export { CURRENT_ENV, ENV_CONFIG } from '../../config/env';
