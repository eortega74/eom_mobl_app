﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Entities
{
    public class PersistedGrantDataView
    {
        public string SubjectId { get; set; }

        public string SubjectName { get; set; }
    }
}
