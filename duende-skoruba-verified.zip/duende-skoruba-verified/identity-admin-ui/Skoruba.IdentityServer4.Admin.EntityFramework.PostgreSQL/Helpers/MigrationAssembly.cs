﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.PostgreSQL.Helpers
{
    public class MigrationAssembly
    {
        
    }
}