﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Extensions.Enums
{
    public enum SavedStatus
    {
        WillBeSavedExplicitly = 0
    }
}
