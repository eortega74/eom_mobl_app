﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Configuration.Configuration
{
    public class DatabaseProviderConfiguration
    {
        public DatabaseProviderType ProviderType { get; set; }
    }
}