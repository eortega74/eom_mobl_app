﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Configuration.Configuration
{
    public class SeedConfiguration
    {
        public bool ApplySeed { get; set; } = false;
    }
}