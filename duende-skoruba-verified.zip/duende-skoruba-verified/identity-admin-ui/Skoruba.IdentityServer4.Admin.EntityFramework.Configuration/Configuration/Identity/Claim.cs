﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Configuration.Configuration.Identity
{
    public class Claim
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
