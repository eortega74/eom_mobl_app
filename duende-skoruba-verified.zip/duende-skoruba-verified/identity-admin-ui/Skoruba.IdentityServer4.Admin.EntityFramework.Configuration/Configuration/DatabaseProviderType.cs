﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.Configuration.Configuration
{
    public enum DatabaseProviderType
    {
        SqlServer,
        PostgreSQL,
        MySql
    }
}
