﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.SqlServer.Helpers
{
    public class MigrationAssembly
    {
        
    }
}