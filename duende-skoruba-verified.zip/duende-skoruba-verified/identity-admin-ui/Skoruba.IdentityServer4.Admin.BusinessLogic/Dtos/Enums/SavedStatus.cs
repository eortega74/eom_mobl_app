﻿namespace Skoruba.IdentityServer4.Admin.BusinessLogic.Dtos.Enums
{
    public enum SavedStatus
    {
        WillBeSavedExplicitly = 0
    }
}
