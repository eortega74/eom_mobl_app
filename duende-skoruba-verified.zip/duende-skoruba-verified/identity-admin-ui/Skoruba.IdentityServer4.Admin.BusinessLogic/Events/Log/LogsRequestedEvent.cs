﻿using Skoruba.AuditLogging.Events;

namespace Skoruba.IdentityServer4.Admin.BusinessLogic.Events.Log
{
    public class LogsRequestedEvent : AuditEvent
    {
    }
}