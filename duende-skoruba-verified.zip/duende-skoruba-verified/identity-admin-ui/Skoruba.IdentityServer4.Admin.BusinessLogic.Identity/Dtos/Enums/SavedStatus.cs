﻿namespace Skoruba.IdentityServer4.Admin.BusinessLogic.Identity.Dtos.Enums
{
    public enum SavedStatus
    {
        WillBeSavedExplicitly = 0
    }
}
