﻿namespace Skoruba.IdentityServer4.Admin.BusinessLogic.Identity.Helpers
{
    public class ResourceMessage
    {
        public string Code { get; set; }

        public string Description { get; set; }
    }
}
