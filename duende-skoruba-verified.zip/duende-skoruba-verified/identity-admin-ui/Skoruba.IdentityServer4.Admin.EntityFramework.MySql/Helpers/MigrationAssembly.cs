﻿namespace Skoruba.IdentityServer4.Admin.EntityFramework.MySql.Helpers
{
    public class MigrationAssembly
    {
        
    }
}