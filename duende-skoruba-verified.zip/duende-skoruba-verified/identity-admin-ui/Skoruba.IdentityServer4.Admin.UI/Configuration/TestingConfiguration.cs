﻿namespace Skoruba.IdentityServer4.Admin.UI.Configuration
{
	public class TestingConfiguration
	{
		/// <summary>
		/// Use test instead of production services and pipelines.
		/// </summary>
		public bool IsStaging { get; set; }
	}
}
