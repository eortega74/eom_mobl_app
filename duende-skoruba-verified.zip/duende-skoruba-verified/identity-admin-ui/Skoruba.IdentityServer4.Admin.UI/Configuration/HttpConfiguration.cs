﻿namespace Skoruba.IdentityServer4.Admin.UI.Configuration
{
	public class HttpConfiguration
	{
		public string BasePath { get; set; } = "";
	}
}
