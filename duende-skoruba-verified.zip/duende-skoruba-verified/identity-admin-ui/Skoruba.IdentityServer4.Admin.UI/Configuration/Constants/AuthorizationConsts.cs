﻿namespace Skoruba.IdentityServer4.Admin.UI.Configuration.Constants
{
    public class AuthorizationConsts
    {
        public const string AdministrationPolicy = "RequireAdministratorRole";
    }
}
