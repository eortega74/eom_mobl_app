﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skoruba.IdentityServer4.Admin.UI.Configuration.Constants
{
    public class CommonConsts
    {
        public const string AdminUIArea = "AdminUI";
    }
}
