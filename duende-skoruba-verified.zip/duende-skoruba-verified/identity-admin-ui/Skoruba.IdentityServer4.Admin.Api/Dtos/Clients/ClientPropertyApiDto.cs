﻿namespace Skoruba.IdentityServer4.Admin.Api.Dtos.Clients
{
    public class ClientPropertyApiDto
    {
        public int Id { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
}