﻿namespace Skoruba.IdentityServer4.Admin.Api.Dtos.ApiScopes
{
    public class ApiScopePropertyApiDto
    {
        public int Id { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
}