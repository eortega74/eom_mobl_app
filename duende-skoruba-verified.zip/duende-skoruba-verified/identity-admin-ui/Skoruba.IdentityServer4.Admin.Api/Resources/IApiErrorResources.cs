﻿using Skoruba.IdentityServer4.Admin.Api.ExceptionHandling;

namespace Skoruba.IdentityServer4.Admin.Api.Resources
{
    public interface IApiErrorResources
    {
        ApiError CannotSetId();
    }
}