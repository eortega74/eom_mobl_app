﻿namespace Skoruba.IdentityServer4.Admin.Api.ExceptionHandling
{
    public class ApiError
    {
        public string Code { get; set; }

        public string Description { get; set; }
    }
}